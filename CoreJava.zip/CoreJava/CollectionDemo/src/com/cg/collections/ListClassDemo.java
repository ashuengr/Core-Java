package com.cg.collections;
import com.cg.beans.Associate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
public class ListClassDemo {
 public static void arrayListClassDemo() {
	 ArrayList<String>strList=new ArrayList<>();
	 
	 strList.add("Ashu");
	 strList.add("Satish");
	 strList.add("Ayush");
	 strList.add("Nilesh");
	 strList.add("Ashu");
	 strList.add("Akash");
	 
	 System.out.println(strList);
	 
	 String nameToBeSearch="Ayush";
	 System.out.println(strList.contains(nameToBeSearch));
	 
	 ArrayList <Associate>associates=new ArrayList<>();
	 associates.add(new Associate(111,"Ashu",15000));
	 associates.add(new Associate(111,"Akash",15000));
	 associates.add(new Associate(111,"Ashu",15000));
	 associates.add(new Associate(111,"satish",15000));
	 Collections.sort(associates);
	 
	 for(Associate associate:associates) {
		 System.out.println(associate);
	 }
	 System.out.println("***********");
	 
	 Collections.sort(associate, newAssociateComparator());
	 for(Associate associate:associates) {
		 System.out.println(associate);

		 Hashtable<Integer,Associate>associates=new Hashtable<>();
		 associates.put(111,new Associate(111,"Ashu",15000));
		 associates.put(114,new Associate(114,"Akash",25000));
		 associates.put(112,new Associate(112,"Ashu",50000));
		 associates.put(115,new Associate(115,"satish",65000));
		 Associate associate=associates.get(112);
		 associates.remove(112);
		 Set<Integer>keys=associates.keyset();
		 for(Integer key:keys) {
			 System.out.println(associates.get
		 }
			 
 }
}
}
