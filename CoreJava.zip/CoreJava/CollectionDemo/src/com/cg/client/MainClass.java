package com.cg.client;
public class MainClass {

	public static void main(String[] args) {
		ListClassesDemo.arrayListClassDemo();

	}

}
