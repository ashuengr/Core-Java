package com.cg.project.innerdemo;

public class MainClass {
 public static void main(String ar[]) {
	 Hotelclass hotel=new Hotelclass();
	 Hotelclass.VegKitchen vegkitchen=hotel.new VegKitchen();
	 Hotelclass.NonvegKitchen nonvegkitchen=hotel.new NonvegKitchen();
 }
}
