package com.cg.project.innerdemo;

public class Hotelclass {
interface FoodOrderListner{
	void cookAFood(String foodName);
}
class VegKitchen implements FoodOrderListner{
	
	public void cookAFood(String foodName) {
		System.out.println(foodName+"is ready");
	}
}
 class NonvegKitchen implements FoodOrderListner{
	
	public void cookAFood(String foodName) {
		System.out.println(foodName+"is ready");
	}
}
}