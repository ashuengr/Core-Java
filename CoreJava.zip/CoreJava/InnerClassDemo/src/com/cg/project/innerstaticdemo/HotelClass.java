package com.cg.project.innerstaticdemo;
public class HotelClass {
	interface FoodOrderListner{
		void cookAFood(String foodName);
	}
	static class VegKitchen implements FoodOrderListner{
		
		public void cookAFood(String foodName) {
			System.out.println(foodName+"is ready");
		}
	}
	static class NonvegKitchen implements FoodOrderListner{
		
		public void cookAFood(String foodName) {
			System.out.println(foodName+"is ready");
		}
	}
}
