package com.cg.project.innerstaticdemo;

import com.cg.project.innerstaticdemo.HotelClass;
public class Main {
	public static void main(String ar[]) {

		 HotelClass.VegKitchen vegkitchen= new VegKitchen();
		 HotelClass.NonvegKitchen nonvegkitchen=HotelClass.new NonvegKitchen();
}
}