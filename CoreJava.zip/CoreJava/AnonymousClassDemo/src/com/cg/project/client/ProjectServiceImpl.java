package com.cg.project.client;

public class ProjectServiceImpl implements ProjectServices{
	public void developeProject() {
		System.out.println("Project is developing");
	}

}
