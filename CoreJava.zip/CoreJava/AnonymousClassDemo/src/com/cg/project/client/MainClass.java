package com.cg.project.client;

public class MainClass {

	public static void main(String[] args) {
	ProjectServices services=new ProjectServices() {
		public void developeProject() {
			System.out.println("It project has developed");
		}
	};

	}

}
