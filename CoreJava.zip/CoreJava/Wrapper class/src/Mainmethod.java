
public class Mainmethod 
{
 public static void main(String ar[])
 {
	 int num=100;
	 Integer obj=num;
	 
	 Integer obj1=200;
	 int num1=obj1;
	 Integer sum=num+obj1+obj+100;
	 System.out.println(sum);
 }
}
