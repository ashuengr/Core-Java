package com.cg.payroll.client;
import com.cg.payroll.services.payrollServices ;
import com.cg.payroll.services.PayrollServiceImpl ;
public class MainClass 
{
 public static void main(String ar[])
 {
	 payrollServices services=new PayrollServiceImpl();
	 int associateId=services.acceptAssociateDetails("Ashutosh", "Mishra", "abcd@gmail.com", "Cse", "Analyst", "asff", 12, 10000, 10, 20, 12345, "SBI", "SBIN");
	 System.out.println("associateId:"+associateId);
	 
	 payrollServices services1=new PayrollServiceImpl();
     associateId=services1.acceptAssociateDetails("Akash", "Mishra", "abcd@gmail.com", "Cse", "Analyst", "asff", 12, 10000, 10, 20, 12345, "SBI", "SBIN");
	 System.out.println("associateId:"+associateId);

 }
}
