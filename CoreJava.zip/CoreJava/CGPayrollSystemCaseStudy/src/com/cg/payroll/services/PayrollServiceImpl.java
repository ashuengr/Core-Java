package com.cg.payroll.services;
import com.cg.payroll.daoservices.*;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.exception.AssociateDetailNotFoundException;
import java.util.List;

public class PayrollServiceImpl implements payrollServices  {
	private AssociateDao associateDao=new AssociateDAOImpl();

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
        /*BankDetails bankDetails=new BankDetails(accountNumber,bankName,ifscCode);
        Salary salary=new Salary(basicSalary, epf, companyPf);
        Associate associate=new Associate(yearlyInvestmentUnder8oC,firstName,lastName,department,designation,pancard,emailId);*/
	    Associate associate = new Associate(yearlyInvestmentUnder8oC,firstName,lastName,department,designation,pancard,emailId,new Salary(basicSalary, epf, companyPf),new BankDetails(accountNumber, bankName,ifscCode));
	    associate=associateDao.save(associate);
		return associate.getAssociateId();
	}
	
	@Override
public int calculateNetSalary(int associateId) throws AssociateDetailNotfoundException {
		Associate associate = associateDAO.findOne(associateId);
		int netSalary =0 ;
		if(associate==null) {
			throw new AssociateDetailNotfoundException("Associate details not found for Id" + associateId);
		}
		else {
			
			int basicSalary = associate.getSalary().getBasicSalary() ;
			int monthlyGrossSalary = (int)(basicSalary + (basicSalary*0.7));
			int annualGrossSalary = 12 * monthlyGrossSalary; 
			int investment = associate.getYearlyInvcestmentUnder80C() + associate.getSalary().getEpf() + associate.getSalary().getCompanyPf() ; 
			if(investment >=150000) {
				investment = 150000;
			}
			//int taxableAmount = annualGrossSalary - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf() ; 
			if(annualGrossSalary<250000) {
				 netSalary = annualGrossSalary - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf() ;
			}
			else if(annualGrossSalary>=250000 && annualGrossSalary<500000){
				 netSalary = (int) (annualGrossSalary - (( annualGrossSalary - investment ) * 0.1 ) - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf());
			}
			else if(annualGrossSalary>=500000 && annualGrossSalary < 1000000) {
				int tax2 = (int) ((annualGrossSalary - 500000) * 0.2);
				int tax1 =  (int) ((250000 - investment)*0.1);
				 netSalary = annualGrossSalary - tax1 - tax2 - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf();
			}
			else if(annualGrossSalary>=1000000) {
				int tax3 = (int) ((annualGrossSalary - 1000000 ) *0.3);
				int tax2 = 100000;
				int tax1  = (int) ((250000 - investment) * 0.1);
				netSalary = annualGrossSalary - tax1 - tax2 - tax3 - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf();
			}
			return netSalary;
		}   
			
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailNotFoundException {
		Associate associate=associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailNotFoundException("Associate details not found for id"+associateId);
		return associate;
	}

	@Override
	public List<Associate>getAssociateDetails() {
		
		return associateDao.findAll();
	}
	
	
} 

	