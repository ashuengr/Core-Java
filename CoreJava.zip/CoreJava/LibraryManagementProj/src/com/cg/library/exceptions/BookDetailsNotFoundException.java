package com.cg.library.exceptions;

import java.io.PrintStream;
import java.io.PrintWriter;

public class BookDetailsNotFoundException extends Exception{

	public BookDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public BookDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BookDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BookDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
