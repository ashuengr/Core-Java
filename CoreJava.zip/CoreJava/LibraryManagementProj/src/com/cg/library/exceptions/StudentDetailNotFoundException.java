package com.cg.library.exceptions;

public class StudentDetailNotFoundException extends Exception{

	public StudentDetailNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentDetailNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public StudentDetailNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public StudentDetailNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StudentDetailNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
