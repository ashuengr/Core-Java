package com.cg.library.daoservice;

import java.util.List;

import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
public interface LibraryDao {
	Student save(Student student);
	boolean update(Student student);
	Book findOne(int studentId);
	List<Student> findAll();

}
