package com.cg.library.daoservice;

import java.util.List;

import com.cg.library.beans.Book;

public class LibraryDaoImpl implements LibraryDao{

	@Override
	public Book save(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(Book book) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Book findOne(int bookId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
