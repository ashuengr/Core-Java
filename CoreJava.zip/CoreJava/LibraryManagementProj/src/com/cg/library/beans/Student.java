package com.cg.library.beans;

public class Student {
private int studentId;
private String studentName;
private String studentSection;
private String studentBranch;
private String studentAddress;
private String studentMailId;
private long studentContactNo;
private Book book;
public Student( String studentName, String studentSection, String studentBranch, String studentAddress,
		String studentMailId, long studentContactNo, Book book) {
	super();
	this.studentName = studentName;
	this.studentSection = studentSection;
	this.studentBranch = studentBranch;
	this.studentAddress = studentAddress;
	this.studentMailId = studentMailId;
	this.studentContactNo = studentContactNo;
	this.book = book;
}
public int getStudentId() {
	return studentId;
}
public void setStudentId(int studentId) {
	this.studentId = studentId;
}
public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
public String getStudentSection() {
	return studentSection;
}
public void setStudentSection(String studentSection) {
	this.studentSection = studentSection;
}
public String getStudentBranch() {
	return studentBranch;
}
public void setStudentBranch(String studentBranch) {
	this.studentBranch = studentBranch;
}
public String getStudentAddress() {
	return studentAddress;
}
public void setStudentAddress(String studentAddress) {
	this.studentAddress = studentAddress;
}
public String getStudentMailId() {
	return studentMailId;
}
public void setStudentMailId(String studentMailId) {
	this.studentMailId = studentMailId;
}
public long getStudentContactNo() {
	return studentContactNo;
}
public void setStudentContactNo(long studentContactNo) {
	this.studentContactNo = studentContactNo;
}
public Book getBook() {
	return book;
}
public void setBook(Book book) {
	this.book = book;
}

}

