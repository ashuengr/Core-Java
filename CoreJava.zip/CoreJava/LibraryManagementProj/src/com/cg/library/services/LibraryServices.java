package com.cg.library.services;

import java.util.Date;
import java.util.List;
import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.exceptions.LibraryServiceDownException;
import com.cg.library.exceptions.StudentDetailNotFoundException;

public interface LibraryServices {
int acceptStudentDetails(String studentName, String studentSection, String studentBranch, String studentAddress,
		String studentMailId, int studentContactNo, Book book);
int calculateFine(int studentId,Date issueDate,Date depositDate)throws StudentDetailNotFoundException ;
Student getStudentDetails(int studentId)throws StudentDetailNotFoundException,LibraryServiceDownException;
List<Student> getAllStudentDetails();
}
