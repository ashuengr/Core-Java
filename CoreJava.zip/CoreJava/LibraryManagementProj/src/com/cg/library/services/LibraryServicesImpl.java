package com.cg.library.services;

import java.util.Date;
import java.util.List;

import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.daoservice.LibraryDao;
import com.cg.library.daoservice.LibraryDaoImpl;
import com.cg.library.exceptions.LibraryServiceDownException;
import com.cg.library.exceptions.StudentDetailNotFoundException;

public class LibraryServicesImpl implements LibraryServices{
    private LibraryDao libraryDao=new LibraryDaoImpl();
	@Override
	public int acceptStudentDetails(String studentName, String studentSection, String studentBranch,
			String studentAddress, String studentMailId, int studentContactNo, Book book) {
	 Book book1=new Book(101,"Java Basics","Java","K arun");
	 Student student=new Student("Ashutosh Mishra","A","CSE","Kolkata","ashu@gmail.com",86971,book1);
	 student=libraryDao.save(student);
		return student.getStudentId();
	}

	@Override
	public int calculateFine(int studentId, Date issueDate, Date depositDate) throws StudentDetailNotFoundException {
		
	
	}

	@Override
	public Student getStudentDetails(int studentId) throws StudentDetailNotFoundException, LibraryServiceDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> getAllStudentDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
