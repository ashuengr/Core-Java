package com.cg.project.lambdaexpr;

public interface WorkService {
	 public void doSomeWork();
}
