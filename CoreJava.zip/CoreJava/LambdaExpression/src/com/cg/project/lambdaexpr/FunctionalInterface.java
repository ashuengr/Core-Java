package com.cg.project.lambdaexpr;

public interface FunctionalInterface {
void greetUser(String firstName,String lastName);
}
