package com.cg.project.lambdaexpr;

public class Mainclass {

	public static void main(String[] args) {
	/* WorkService service=new WorkService() {
		 public void doSomeWork() {
			System.out.println("do some work"); 
		 }
	 };
  service.doSomeWork();
  WorkService  service1 =()->{
	  System.out.println("Work in progress");
	  System.out.println("Work is done");
  };*/
		/*FunctionalInterface ref1=(firstName,lastName)->System.out.println("Good afternoon "+firstName+" "+lastName);
		ref1.greetUser("Ashutosh","Mishra");*/
		FunctionalInterface2 ref2=(a,b)->a+b;
	}
public static void callForwork(WorkService service) {
	service.doSomeWork();
}
}
